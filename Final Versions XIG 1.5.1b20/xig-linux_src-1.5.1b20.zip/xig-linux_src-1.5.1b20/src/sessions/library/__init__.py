"""
XIG Session Common Code Library
"""
__version__ = '1.0.0'
__author__ = 'Jordan Husney'
__license__ = 'LGPL'

